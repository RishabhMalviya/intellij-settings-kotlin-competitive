package ${NAME}


class Solution {
    fun ${NAME}(): Unit {

    }
}

fun main() {
    val solution = Solution()
    print(solution.${NAME}())
}