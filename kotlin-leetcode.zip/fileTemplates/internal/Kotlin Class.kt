package ${NAME}


private fun Int.modPositive(other: Int): Int = if(this%(other)<0) (this%(other))+(other) else (this%(other))

class Solution {
    fun ${NAME}(): Unit {

    }
}

fun main() {
    val solution = Solution()
    print(solution.${NAME}())
}